Besides the META-INF folder, you will find nothing packed in, which is the way it was supposed to be.

Everything is done by the update-binary, which is a script.

Original version by Shoey63
Moved in to the updater-binary by [NUT]
